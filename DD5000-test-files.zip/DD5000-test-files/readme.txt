These are sample files required for the UNIT tests of the DD-5000.
To allow for the unit tests to operate on actual files, place SubmissionTestDir adn TemplateTestDir in /tmp. So that you have:
/tmp/SubmissionTestDir
/tmp/TemplateTestDir

TemplateTestDir contains a TouchCORE project that provides an assumed base structure, common to all solutions. Ecore identifiers of this template must be excluded from analysis.
DeubmissionTestDir contains three sample submission of StudentA, StudentB, StudentC. StudentB copied the solution of StudentA and renamed some elements. The ecore identfiers however are unchanged. StudentC created an entirely different solution based on the template.
The unit tests must identify that A and B have collisions, while C has no collisisions.

Namely the following ecore identifiers should we detected:
List of collisions: (template IDs filtered)
_MRBUl4vZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_MRBUmYvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_MRBUmovZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_MQ7N8IvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_H1C4gIvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_LS-_AovZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_MQ7N8YvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_J0luYIvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_MQ7N8ovZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_H1C4gYvZEeuyz5hrMJJE7Q: [StudentB | StudentA]
_H1C4govZEeuyz5hrMJJE7Q: [StudentB | StudentA]